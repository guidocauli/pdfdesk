# PDFDesk — Guido Cauli <guido.cauli@gmail.com>
# Scansione da scanner: SANE (Linux, macOS con sane-backends) e WIA (Windows); creazione di PDF dalle immagini acquisite.
from __future__ import annotations

import io
import os
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from typing import Callable, Optional

import pymupdf as fitz
from .i18n import tr

MODES = {"color": tr("Colore"), "gray": tr("Scala di grigi"), "bw": tr("Bianco e nero")}
SOURCES = {"flatbed": tr("Piano di scansione"), "adf": tr("Alimentatore automatico (ADF)")}
# formati carta in mm (larghezza, altezza); None = area massima dello scanner
PAPER = {"max": (tr("Area massima"), None), "a4": ("A4", (210, 297)), "a5": ("A5", (148, 210)),
         "letter": ("Letter", (216, 279)), "legal": ("Legal", (216, 356)), "a3": ("A3", (297, 420))}
SANE_MODE = {"color": "Color", "gray": "Gray", "bw": "Lineart"}


class ScanError(Exception):
    pass


@dataclass
class Scanner:
    backend: str        # "sane" | "wia"
    id: str
    name: str

    @property
    def label(self) -> str:
        return f"{self.name}  [{self.backend.upper()}]"


@dataclass
class ScanParams:
    mode: str = "color"
    dpi: int = 300
    source: str = "flatbed"
    paper: str = "a4"


def _hidden() -> dict:
    if os.name == "nt":
        si = subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        return {"startupinfo": si, "creationflags": 0x08000000}
    return {}


def _run(cmd: list[str], timeout: int = 120, **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, timeout=timeout, **_hidden(), **kw)


def scanimage_path() -> Optional[str]:
    return shutil.which("scanimage")


def _powershell() -> Optional[str]:
    return shutil.which("powershell") or shutil.which("pwsh")


def available_backends() -> list[str]:
    out = []
    if scanimage_path():
        out.append("sane")
    if os.name == "nt" and _powershell():
        out.append("wia")
    return out


# ---------------------------------------------------------------------- SANE
def sane_list() -> list[Scanner]:
    exe = scanimage_path()
    if not exe:
        return []
    r = _run([exe, "-f", "%d|%v %m|%t%n"], timeout=60)
    res = []
    for line in r.stdout.decode("utf-8", "replace").splitlines():
        parts = line.split("|")
        if len(parts) >= 2 and parts[0].strip():
            res.append(Scanner("sane", parts[0].strip(), parts[1].strip()))
    return res


def _sane_cmd(dev: str, prm: ScanParams, fmt: str = "png") -> list[str]:
    cmd = [scanimage_path() or "scanimage", "-d", dev, f"--format={fmt}", f"--resolution={prm.dpi}",
           f"--mode={SANE_MODE.get(prm.mode, 'Color')}"]
    if prm.source == "adf":
        cmd += ["--source", "ADF"]
    elif prm.source == "flatbed":
        cmd += ["--source", "Flatbed"]
    size = PAPER.get(prm.paper, PAPER["max"])[1]
    if size:
        cmd += ["-l", "0", "-t", "0", "-x", str(size[0]), "-y", str(size[1])]
    return cmd


def _next_name(folder: str) -> str:
    n = len([f for f in os.listdir(folder) if f.startswith("scan") and f.endswith(".png")]) + 1
    return os.path.join(folder, f"scan{n:04d}.png")


def sane_scan(dev: str, prm: ScanParams, folder: str, progress: Optional[Callable[[int], bool]] = None) -> list[str]:
    """Acquisisce una pagina (piano) o tutte le pagine dell'alimentatore. Restituisce i file PNG."""
    base = _sane_cmd(dev, prm)
    if prm.source == "adf":
        sub = tempfile.mkdtemp(prefix="batch", dir=folder)
        r = _run(base + [f"--batch={os.path.join(sub, 'p%04d.png')}", "--batch-start=1"], timeout=1800)
        got = sorted(os.path.join(sub, x) for x in os.listdir(sub) if x.endswith(".png"))
        # un alimentatore che si svuota termina con errore «out of documents»: se ci sono pagine, è normale
        if not got and r.returncode != 0:
            shutil.rmtree(sub, ignore_errors=True)
            raise ScanError(r.stderr.decode("utf-8", "replace").strip() or tr("scansione non riuscita"))
        files = []
        for g in got:              # nomi progressivi unici: più scansioni successive non si sovrascrivono
            dst = _next_name(folder)
            shutil.move(g, dst); files.append(dst)
        shutil.rmtree(sub, ignore_errors=True)
        return files
    r = _run(base, timeout=600)
    if r.returncode != 0 or not r.stdout:
        msg = r.stderr.decode("utf-8", "replace").strip()
        # alcuni scanner non hanno l'opzione --source: ritenta senza
        if "source" in msg.lower() and "--source" in base:
            i = base.index("--source")
            r = _run(base[:i] + base[i + 2:], timeout=600)
            msg = r.stderr.decode("utf-8", "replace").strip()
        if r.returncode != 0 or not r.stdout:
            raise ScanError(msg or "scansione non riuscita")
    path = _next_name(folder)
    with open(path, "wb") as f:
        f.write(r.stdout)
    return [path]


# ---------------------------------------------------------------------- WIA (Windows)
_WIA_LIST = r"""
$ErrorActionPreference='Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8      # nomi degli scanner con lettere accentate
$m = New-Object -ComObject WIA.DeviceManager
foreach ($d in $m.DeviceInfos) { if ($d.Type -eq 1) { "{0}|{1}" -f $d.DeviceID, $d.Properties.Item('Name').Value } }
"""

_WIA_SCAN = r"""
param([string]$DevId,[int]$Dpi,[int]$Intent,[int]$Adf,[int]$W,[int]$H,[string]$Out)
$ErrorActionPreference='Stop'
function SetP($o,$id,$v){ try { $o.Properties.Item($id).Value = $v } catch {} }
$m = New-Object -ComObject WIA.DeviceManager
$info = $null
foreach ($d in $m.DeviceInfos) { if ($d.DeviceID -eq $DevId) { $info = $d } }
if ($info -eq $null) { throw 'Scanner non trovato' }
$scanner = $info.Connect()            # NB: PowerShell non distingue maiuscole/minuscole: «$dev» sarebbe il parametro [string] -Dev
if ($scanner -eq $null) { throw 'Impossibile collegarsi allo scanner' }
$i = 0
do {
  if ($Adf -eq 1) { SetP $scanner 3088 1 } else { SetP $scanner 3088 2 }
  $item = $scanner.Items.Item(1)
  SetP $item 6146 $Intent
  SetP $item 6147 $Dpi
  SetP $item 6148 $Dpi
  SetP $item 6149 0
  SetP $item 6150 0
  if ($W -gt 0) { SetP $item 6151 ([int]($W / 25.4 * $Dpi)); SetP $item 6152 ([int]($H / 25.4 * $Dpi)) }
  try { $img = $item.Transfer('{B96B3CAF-0728-11D3-9D7B-0000F81EF32E}') } catch {
    if ($i -gt 0) { break } else { throw }
  }
  $i++
  $f = Join-Path $Out ('scan{0:D4}.png' -f $i)
  $img.SaveFile($f)
  if ($Adf -ne 1) { break }
  # altra pagina nell'alimentatore? (bit 1 di «Document Handling Status» = feeder pronto)
  $st = 0; try { $st = $scanner.Properties.Item(3087).Value } catch {}
  if (($st -band 1) -eq 0) { break }
} while ($true)
"""


def wia_list() -> list[Scanner]:
    ps = _powershell()
    if os.name != "nt" or not ps:
        return []
    r = _run([ps, "-NoProfile", "-NonInteractive", "-Command", _WIA_LIST], timeout=60)
    res = []
    for line in r.stdout.decode("utf-8", "replace").splitlines():
        if "|" in line:
            a, b = line.split("|", 1)
            res.append(Scanner("wia", a.strip(), b.strip()))
    return res


def wia_scan(dev: str, prm: ScanParams, folder: str) -> list[str]:
    ps = _powershell()
    if not ps:
        raise ScanError(tr("PowerShell non disponibile"))
    script = os.path.join(folder, "wia_scan.ps1")
    with open(script, "w", encoding="utf-8-sig") as f:
        f.write(_WIA_SCAN)
    size = PAPER.get(prm.paper, PAPER["max"])[1] or (0, 0)
    intent = {"color": 1, "gray": 2, "bw": 4}.get(prm.mode, 1)
    out = os.path.join(folder, "wia")
    os.makedirs(out, exist_ok=True)
    r = _run([ps, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script, "-DevId", dev,
              "-Dpi", str(prm.dpi), "-Intent", str(intent), "-Adf", "1" if prm.source == "adf" else "0",
              "-W", str(size[0]), "-H", str(size[1]), "-Out", out], timeout=1800)
    files = sorted(os.path.join(out, x) for x in os.listdir(out) if x.endswith(".png"))
    if not files:
        raise ScanError(r.stderr.decode("utf-8", "replace").strip() or "scansione non riuscita")
    final = []
    for f in files:                       # sposta nella cartella principale con numerazione progressiva
        dst = _next_name(folder)
        shutil.move(f, dst); final.append(dst)
    shutil.rmtree(out, ignore_errors=True)
    return final


# ---------------------------------------------------------------------- interfaccia comune
def list_scanners() -> list[Scanner]:
    res = []
    for fn in (wia_list, sane_list):
        try:
            res += fn()
        except Exception:
            pass
    return res


def scan_pages(sc: Scanner, prm: ScanParams, folder: str) -> list[str]:
    os.makedirs(folder, exist_ok=True)
    try:
        return wia_scan(sc.id, prm, folder) if sc.backend == "wia" else sane_scan(sc.id, prm, folder)
    except subprocess.TimeoutExpired as e:
        raise ScanError(tr("lo scanner non ha risposto in tempo")) from e
    except FileNotFoundError as e:
        raise ScanError(str(e)) from e


# ---------------------------------------------------------------------- immagini → PDF
# OCR: Tesseract non è incluso nel programma. Su Windows l'installatore (componente «OCR») e il pulsante «Scarica OCR» lo scaricano
# da internet: versione fissata e controllo SHA-256 prima dell'esecuzione. Altrove si installa con il gestore pacchetti.
TESSERACT_VERSION = "5.3.0.20221214"
TESSERACT_URL = "https://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-w64-setup-v5.3.0.20221214.exe"
TESSERACT_SHA256 = "175a326853f87474132c284072a821dd819c63b707b01879b309f80bd6c0ab1e"
TESSDATA_URL = "https://github.com/tesseract-ocr/tessdata_fast/raw/main/{lang}.traineddata"
OCR_DOWNLOAD_LANGS = ("ita",)           # oltre all'inglese, già compreso nell'installer di Tesseract
OCR_INSTALL_HINT = {"debian": "sudo apt install tesseract-ocr tesseract-ocr-ita", "redhat": "sudo dnf install tesseract tesseract-langpack-ita",
                    "arch": "sudo pacman -S tesseract tesseract-data-ita", "macos": "brew install tesseract tesseract-lang"}


def _tess_exe() -> str:
    return "tesseract.exe" if sys.platform == "win32" else "tesseract"


def ocr_install_dir() -> str:
    """Cartella in cui il programma installa Tesseract (solo Windows): accanto all'eseguibile se scrivibile, altrimenti nel profilo."""
    app = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else ""
    if app and os.access(app, os.W_OK):
        return os.path.join(app, "tesseract")
    return os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "PDFDesk", "tesseract")


def ocr_search_dirs() -> list[str]:
    if sys.platform != "win32":
        return []
    d = []
    if getattr(sys, "frozen", False):
        d.append(os.path.join(os.path.dirname(sys.executable), "tesseract"))
    if os.environ.get("LOCALAPPDATA"):
        d.append(os.path.join(os.environ["LOCALAPPDATA"], "PDFDesk", "tesseract"))
    for v in ("PROGRAMFILES", "PROGRAMW6432"):
        if os.environ.get(v):
            d.append(os.path.join(os.environ[v], "Tesseract-OCR"))
    return d


_TESS_OVERRIDE = ""


def set_tesseract_path(path: str) -> None:
    """Percorso scelto dall'utente nelle Preferenze (file eseguibile o cartella che lo contiene); vuoto = ricerca automatica."""
    global _TESS_OVERRIDE
    _TESS_OVERRIDE = (path or "").strip()


def _resolve_tess(path: str) -> Optional[str]:
    if path and os.path.isdir(path):
        path = os.path.join(path, _tess_exe())
    return path if path and os.path.isfile(path) else None


def find_tesseract() -> Optional[str]:
    """Ricerca automatica: PATH, poi le cartelle note (accanto a PDFDesk, profilo utente, C:\\Program Files\\Tesseract-OCR…).
    Non occorre aggiungere Tesseract al PATH."""
    w = shutil.which("tesseract")
    if w:
        return w
    for d in ocr_search_dirs():
        p = _resolve_tess(d)
        if p:
            return p
    return None


def tesseract_path() -> Optional[str]:
    return _resolve_tess(_TESS_OVERRIDE) or find_tesseract()


def _tess_env(tess: str) -> Optional[dict]:
    td = os.path.join(os.path.dirname(tess), "tessdata")
    if os.path.isdir(td) and not os.environ.get("TESSDATA_PREFIX"):
        return {**os.environ, "TESSDATA_PREFIX": td}
    return None


def ocr_hint() -> str:
    """Come attivare l'OCR (testo per l'utente): il motore è incluso, servono solo le lingue."""
    return tr("Scarica le lingue OCR da Preferenze → Scansione e OCR (pulsante «Scarica lingue…»)")


def _download(url: str, dest: str, progress: Optional[Callable[[int, int], bool]] = None, sha256: str = "") -> None:
    """Scarica `url` in `dest`; se `sha256` è dato, il file deve corrispondere, altrimenti viene cancellato e si segnala l'errore."""
    import hashlib
    import urllib.request
    from . import net
    h = hashlib.sha256()
    try:
        with net.urlopen(urllib.request.Request(url, headers={"User-Agent": "PDFDesk"}), timeout=60) as r, open(dest, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0); got = 0
            while True:
                b = r.read(256 * 1024)
                if not b:
                    break
                f.write(b); h.update(b); got += len(b)
                if progress and progress(got, total) is False:
                    raise ScanError(tr("Operazione annullata"))
    except ScanError:
        _rm(dest); raise
    except Exception as e:
        _rm(dest)
        raise ScanError(tr("Download non riuscito: {e}").format(e=e)) from e
    if sha256 and h.hexdigest().lower() != sha256.lower():
        _rm(dest)
        raise ScanError(tr("Il file scaricato non corrisponde al controllo di integrità (SHA-256): installazione annullata"))


def _rm(path: str) -> None:
    try:
        os.remove(path)
    except OSError:
        pass


def _run_setup(exe: str, params: str) -> int:
    """Esegue l'installer NSIS `exe` con la riga di parametri `params` e ne attende la fine; restituisce il codice di uscita.

    Due accorgimenti: (1) la riga di comando si passa come testo, perché NSIS richiede «/D=percorso» come ultimo parametro e SENZA
    virgolette anche se il percorso contiene spazi (subprocess con una lista le aggiungerebbe); (2) se l'installer chiede i privilegi di
    amministratore (errore 740) lo si rilancia con «runas», che mostra la richiesta UAC di Windows."""
    try:
        return subprocess.run(f'"{exe}" {params}', timeout=900).returncode
    except OSError as e:
        if getattr(e, "winerror", None) != 740:
            raise
    return _shell_execute_wait(exe, params, "runas")


def _shell_execute_wait(exe: str, params: str, verb: str = "runas", timeout_ms: int = 900_000) -> int:
    import ctypes
    from ctypes import wintypes

    class SEI(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("fMask", wintypes.ULONG), ("hwnd", wintypes.HWND), ("lpVerb", wintypes.LPCWSTR),
                    ("lpFile", wintypes.LPCWSTR), ("lpParameters", wintypes.LPCWSTR), ("lpDirectory", wintypes.LPCWSTR),
                    ("nShow", ctypes.c_int), ("hInstApp", wintypes.HINSTANCE), ("lpIDList", ctypes.c_void_p), ("lpClass", wintypes.LPCWSTR),
                    ("hkeyClass", wintypes.HKEY), ("dwHotKey", wintypes.DWORD), ("hIcon", wintypes.HANDLE), ("hProcess", wintypes.HANDLE)]
    k32 = ctypes.windll.kernel32
    k32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    k32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    k32.CloseHandle.argtypes = [wintypes.HANDLE]
    ctypes.windll.shell32.ShellExecuteExW.argtypes = [ctypes.POINTER(SEI)]
    sei = SEI(); sei.cbSize = ctypes.sizeof(SEI); sei.fMask = 0x40 | 0x8000        # NOCLOSEPROCESS | NOASYNC
    sei.lpVerb = verb; sei.lpFile = exe; sei.lpParameters = params; sei.nShow = 0
    if not ctypes.windll.shell32.ShellExecuteExW(ctypes.byref(sei)) or not sei.hProcess:
        raise ScanError(tr("Operazione annullata"))          # tipicamente: richiesta UAC rifiutata
    try:
        k32.WaitForSingleObject(sei.hProcess, timeout_ms)
        code = wintypes.DWORD(1)
        k32.GetExitCodeProcess(sei.hProcess, ctypes.byref(code))
        return int(code.value)
    finally:
        k32.CloseHandle(sei.hProcess)


def install_tesseract(dest: str = "", langs: tuple = OCR_DOWNLOAD_LANGS,
                      progress: Optional[Callable[[str, int, int], bool]] = None) -> str:
    """Windows: scarica e installa Tesseract (e le lingue extra) in `dest`; restituisce il percorso di tesseract.exe."""
    if sys.platform != "win32":
        raise ScanError(tr("Installazione automatica disponibile solo su Windows") + ": " + ocr_hint())
    dest = dest or ocr_install_dir()
    tmp = tempfile.mkdtemp(prefix="pdfdesk-tess-")
    try:
        def cb(what):
            return (lambda a, b: progress(what, a, b)) if progress else None
        setup = os.path.join(tmp, "tesseract-setup.exe")
        _download(TESSERACT_URL, setup, cb("Tesseract"), TESSERACT_SHA256)
        os.makedirs(dest, exist_ok=True)
        code = _run_setup(setup, "/S /D=" + dest)
        exe = os.path.join(dest, "tesseract.exe")
        if code != 0 or not os.path.isfile(exe):
            raise ScanError(tr("L'installazione di Tesseract non è riuscita (codice {c})").format(c=code))
        td = os.path.join(dest, "tessdata"); os.makedirs(td, exist_ok=True)
        for lg in langs:
            if not os.path.isfile(os.path.join(td, lg + ".traineddata")):
                _download(TESSDATA_URL.format(lang=lg), os.path.join(td, lg + ".traineddata"), cb(lg))
        return exe
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def images_to_pdf(files: list[str], out_path: str, dpi: int = 300, jpeg_quality: int = 0, ocr_lang: str = "",
                  progress: Optional[Callable[[int, int], bool]] = None, title: str = "") -> int:
    """Crea un PDF con una pagina per immagine, alla dimensione fisica data da `dpi`.

    `jpeg_quality` > 0: ricodifica le pagine a colori/grigio come JPEG (file molto più piccolo).
    `ocr_lang`: lingua Tesseract (es. «ita+eng»): il testo riconosciuto rende il PDF ricercabile.
    """
    from PIL import Image
    if not files:
        raise ScanError(tr("Nessuna pagina"))
    out = fitz.open()
    # OCR: motore integrato (servono solo i dati delle lingue); se manca, Tesseract esterno
    from . import ocr as _ocr
    builtin = None
    tess = None
    if ocr_lang:
        try:
            builtin = _ocr.resolve(ocr_lang) if _ocr.engine_ok() else None
        except _ocr.OcrError:
            builtin = None
        tess = None if builtin else tesseract_path()
    n = len(files)
    try:
        for i, f in enumerate(files):
            if progress and progress(i, n) is False:
                raise ScanError(tr("Operazione annullata"))
            im = Image.open(f)
            xres = im.info.get("dpi", (dpi, dpi))[0] or dpi
            try:
                res = int(round(float(xres))) if float(xres) > 1 else dpi
            except Exception:
                res = dpi
            if not im.info.get("dpi"):
                res = dpi
            w, h = im.size
            data = None
            if jpeg_quality and im.mode not in ("1",):
                buf = io.BytesIO(); im.convert("L" if im.mode == "L" else "RGB").save(buf, "JPEG", quality=jpeg_quality, dpi=(res, res))
                data = buf.getvalue()
            else:
                buf = io.BytesIO(); (im if im.mode in ("1", "L", "RGB") else im.convert("RGB")).save(buf, "PNG")
                data = buf.getvalue()
            im.close()
            page = out.new_page(width=w * 72.0 / res, height=h * 72.0 / res)
            page.insert_image(page.rect, stream=data)
            if builtin:
                try:
                    _ocr.ocr_page(page, builtin[0], builtin[1])
                except Exception:
                    pass                                  # pagina senza testo riconosciuto: resta l'immagine
            elif tess:
                _ocr_page(out, page, f, tess, ocr_lang)
        if title:
            out.set_metadata({"title": title})
        out.save(out_path, garbage=3, deflate=True)
        if progress:
            progress(n, n)
        return n
    finally:
        out.close()


def _ocr_page(doc: fitz.Document, page: fitz.Page, img_path: str, tess: str, lang: str) -> None:
    """Sovrappone alla pagina il livello di testo invisibile prodotto da Tesseract (PDF «sandwich»)."""
    tmp = tempfile.mkdtemp(prefix="pdfdesk-ocr-")
    try:
        base = os.path.join(tmp, "o")
        r = _run([tess, img_path, base, "-l", lang, "pdf"], timeout=300, env=_tess_env(tess))
        if r.returncode != 0 or not os.path.exists(base + ".pdf"):
            return
        o = fitz.open(base + ".pdf")
        idx = page.number
        doc.insert_pdf(o, from_page=0, to_page=0, start_at=idx)
        doc.delete_page(idx + 1)
        o.close()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def ocr_languages() -> list[str]:
    """Lingue OCR utilizzabili: quelle del motore integrato (dati scaricati o di sistema), altrimenti quelle del
    Tesseract esterno."""
    from . import ocr as _ocr
    if _ocr.engine_ok():
        langs = _ocr.languages()
        if langs:
            return langs
    t = tesseract_path()
    if not t:
        return []
    try:
        r = _run([t, "--list-langs"], timeout=20, env=_tess_env(t))
        return [x.strip() for x in r.stdout.decode("utf-8", "replace").splitlines()[1:] if x.strip() and x.strip() != "osd"]
    except Exception:
        return []
