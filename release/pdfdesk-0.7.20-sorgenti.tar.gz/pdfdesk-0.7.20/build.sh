#!/usr/bin/env bash
# PDFDesk — Guido Cauli <guido.cauli@gmail.com>
# Compila l'eseguibile per la piattaforma corrente (Linux o macOS), lo collauda e lo impacchetta in dist/.
set -euo pipefail
cd "$(dirname "$0")"
echo "PDFDesk — Guido Cauli <guido.cauli@gmail.com> — build"
[ "${1:-}" = "--help" ] && { echo "uso: ./build.sh [--skip-tests]"; exit 0; }
PY=${PYTHON:-$(command -v python3.11 || command -v python3)}      # Python 3.11 su tutte le piattaforme (vedi requirements.lock)
VER=$(sed -n 's/^__version__ = "\(.*\)"/\1/p' pdfdesk/__init__.py)
$PY -m pip install --no-deps -r requirements.lock      # il lock è completo: nessuna dipendenza in più (es. NumPy, non usato)
$PY check_build_env.py || exit 1               # stesso Python e stesse versioni dei moduli su ogni sistema
if [ "${1:-}" != "--skip-tests" ]; then
  QT_QPA_PLATFORM=offscreen $PY -I -W ignore tests/test_core.py
  QT_QPA_PLATFORM=offscreen $PY -I -W ignore tests/test_gui.py
  QT_QPA_PLATFORM=offscreen $PY -I -W ignore tests/test_features.py
  QT_QPA_PLATFORM=offscreen $PY -I -W ignore tests/test_standards.py
fi
(cd packaging && $PY -m PyInstaller --noconfirm --clean --distpath ../dist --workpath ../build pdfdesk.spec)
OS=$(uname -s | tr '[:upper:]' '[:lower:]'); ARCH=$(uname -m)
if [ "$OS" = "darwin" ]; then
  APP="dist/PDFDesk.app/Contents/MacOS/pdfdesk"; "$APP" --selftest
  (cd dist && ditto -c -k --keepParent PDFDesk.app "pdfdesk-$VER-macos-$ARCH.zip")
  cp packaging/macos/sblocca.sh dist/sblocca.sh && chmod +x dist/sblocca.sh && (cd dist && zip -q -g "pdfdesk-$VER-macos-$ARCH.zip" sblocca.sh)   # script di primo avvio (xattr -cr)
else
  ./dist/pdfdesk --selftest
  PKG="build/pkg/pdfdesk-$VER"                          # il pacchetto si estrae in pdfdesk-<versione>/
  rm -rf build/pkg && mkdir -p "$PKG/icons" && cp dist/pdfdesk LICENSE README.md THIRD_PARTY.md "$PKG/"
  cp packaging/linux/pdfdesk.desktop.in packaging/linux/install.sh packaging/linux/uninstall.sh "$PKG/"
  cp packaging/assets/pdfdesk-*.png packaging/assets/pdfdesk.svg "$PKG/icons/"
  tar -C build/pkg -czf "dist/pdfdesk-$VER-linux-$ARCH.tar.gz" "pdfdesk-$VER"
fi
echo "Pacchetto creato in dist/"
